'use strict';

function measurePage() {
 const nodes = Array.from(document.querySelectorAll('body *')).slice(0, 12000)
  .filter(element => {
   const style = getComputedStyle(element);
   return element.getClientRects().length && style.visibility === 'visible' && style.opacity !== '0';
  });
 const count = selector => nodes.filter(element => element.matches(selector)).length;
 const hasLabel = element => Boolean(
  element.getAttribute('aria-label')?.trim() || element.getAttribute('aria-labelledby') ||
  element.labels?.length || element.textContent.trim() || element.getAttribute('title') ||
  element.querySelector('img[alt]:not([alt=""])')
 );
 const missing = selector => nodes.filter(element => element.matches(selector) && !hasLabel(element)).length;
 const controls = 'button,[role="button"]';
 const fields = 'input:not([type="hidden"]),textarea,select';
 const colors = new Set();
 const contrasts = [];
 function rgb(value) {
  const match = value.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);
  return match?.slice(1).map(Number);
 }
 const hex = triplet => '#' + triplet.map(value => value.toString(16).padStart(2,'0')).join('');
 const luminance = triplet => triplet.map(value => value / 255)
  .map(value => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4)
  .reduce((sum,value,index) => sum + value * [.2126,.7152,.0722][index],0);
 for (const element of nodes.filter(node => node.matches('p,h1,h2,h3,label,button,a')).slice(0,120)) {
  const style = getComputedStyle(element);
  const foreground = rgb(style.color);
  let background;
  for (let parent = element; parent; parent = parent.parentElement) {
   const surface = getComputedStyle(parent);
   if (surface.backgroundImage !== 'none') break;
   background = rgb(surface.backgroundColor);
   if (background || surface.backgroundColor !== 'rgba(0, 0, 0, 0)') break;
  }
  if (!foreground || !background) continue;
  const [first,second] = [luminance(foreground),luminance(background)].sort((a,b)=>b-a);
  const size = parseFloat(style.fontSize);
  const threshold = size >= 24 || (size >= 18.67 && Number(style.fontWeight) >= 700) ? 3 : 4.5;
  colors.add(hex(foreground));
  colors.add(hex(background));
  contrasts.push({ratio:(first+.05)/(second+.05),threshold,fg:hex(foreground),bg:hex(background)});
 }
 const cells = new Set();
 for (const element of nodes.filter(node => node.matches('p,h1,h2,h3,img,button,input,textarea,select')).slice(0,500)) {
  const rect = element.getBoundingClientRect();
  const left = Math.max(0,Math.floor(rect.left / innerWidth * 24));
  const right = Math.min(24,Math.ceil(rect.right / innerWidth * 24));
  const top = Math.max(0,Math.floor(rect.top / innerHeight * 16));
  const bottom = Math.min(16,Math.ceil(rect.bottom / innerHeight * 16));
  for(let y=top;y<bottom;y++) for(let x=left;x<right;x++) cells.add(y*24+x);
 }
 return {
  words:Math.min(200000, document.body.innerText.trim().split(/\s+/u).filter(Boolean).length),nodes:nodes.length,
  h1:count('h1'),h2:count('h2'),images:count('img'),alt_missing:count('img:not([alt])'),
  controls:count(controls),nameless_controls:missing(controls),links:count('a[href]'),nameless_links:missing('a[href]'),
  fields:count(fields),unlabelled_fields:missing(fields),iframes:count('iframe'),
  fonts:new Set(nodes.slice(0,1000).map(element=>getComputedStyle(element).fontFamily)).size,
  whitespace:Math.round(100*(1-cells.size/384)),contrasts,colors:[...colors].slice(0,6),
  title:Boolean(document.title),language:Boolean(document.documentElement.lang),viewport:Boolean(document.querySelector('meta[name=viewport]'))
 };
}

const capture = document.querySelector('#capture');
const code = document.querySelector('#code');
const copy = document.querySelector('#copy');
const status = document.querySelector('#status');
capture.addEventListener('click',async()=>{
 capture.disabled=true;code.hidden=true;copy.hidden=true;
 status.textContent='Интерфейс өлшеніп жатыр…';
 try {
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  const url=new URL(tab?.url);
  if (!['http:','https:'].includes(url.protocol)) throw Error();
  const [snapshot]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:measurePage});
  if (!snapshot?.result) throw Error();
  code.value='VPA1.'+btoa(JSON.stringify({url:url.origin,result:snapshot.result}));
  code.hidden=false;copy.hidden=false;
  status.textContent='Код дайын. Оны VibePrompt AI-дағы Chrome аудитіне қойыңыз.';
 } catch {
  status.textContent='Бұл бетті өлшеу мүмкін болмады. Кәдімгі сайтты ашып, қайта көріңіз.';
 } finally {capture.disabled=false}
});
copy.addEventListener('click',async()=>{
 try {await navigator.clipboard.writeText(code.value);status.textContent='Код көшірілді.'}
 catch {code.focus();code.select();status.textContent='Белгіленген кодты қолмен көшіріңіз.'}
});
